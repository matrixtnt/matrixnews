'use client'
import FeatureLayout from '../features-Style/FeatureLayout'
import Layout from '../layout/Layout'

const Home = () => {
  return (
    <Layout>
      <FeatureLayout />
    </Layout>
  )
}

export default Home
