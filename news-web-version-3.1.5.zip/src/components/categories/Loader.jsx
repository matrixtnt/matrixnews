import React from 'react'

const Loader = () => {
    return (
        <div>
            <div className="formLoaderWrapper">
                <div className="formLoader"></div>
            </div>
        </div>
    )
}

export default Loader
